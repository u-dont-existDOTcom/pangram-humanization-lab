"""Autonomous machine-repair primitives."""
